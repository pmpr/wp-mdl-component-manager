<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56be6e3a1             |
    |_______________________________________|
*/
 use Pmpr\Module\ComponentManager\ComponentManager; ComponentManager::symcgieuakksimmu();
