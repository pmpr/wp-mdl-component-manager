<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d89e69c831             |
    |_______________________________________|
*/
 use Pmpr\Module\ComponentManager\ComponentManager; ComponentManager::symcgieuakksimmu();
