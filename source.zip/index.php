<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5c95242e             |
    |_______________________________________|
*/
 use Pmpr\Module\ComponentManager\ComponentManager; ComponentManager::symcgieuakksimmu();
