<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6678838b736c8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\x74\x74\160\x3a\57\x2f\x69\160\55\141\160\151\x2e\143\157\155\x2f\x6a\163\157\156"; $this->ksiyskmggywgsayu("\x66\151\145\x6c\144\163", "\x31\x34\x37\64\65\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto goeoymmqqqeeoime; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto qmiwsequckckoaei; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\x6e\x74\x72\171\103\x6f\x64\x65"); qmiwsequckckoaei: goeoymmqqqeeoime: return $quscceoaiwasmkcy; } }
