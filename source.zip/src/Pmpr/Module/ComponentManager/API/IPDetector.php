<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5c95242e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\164\x74\x70\x3a\x2f\57\151\160\55\141\x70\151\x2e\x63\x6f\155\x2f\x6a\163\x6f\156"; $this->ksiyskmggywgsayu("\x66\151\145\154\x64\163", "\x31\64\x37\x34\65\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto wkgskiuiukiuyque; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto ukomuiwukymcoaso; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\x6e\164\x72\171\x43\157\144\x65"); ukomuiwukymcoaso: wkgskiuiukiuyque: return $quscceoaiwasmkcy; } }
