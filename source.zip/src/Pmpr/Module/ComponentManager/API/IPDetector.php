<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b939727b32d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\x68\x74\164\160\x3a\x2f\57\151\160\55\141\x70\x69\56\143\157\x6d\57\x6a\x73\157\x6e"; $this->ksiyskmggywgsayu("\x66\x69\145\x6c\144\x73", "\61\64\x37\x34\65\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qogqewiwmwiwskgm; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto qiaqsassksqiuyae; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\156\x74\162\x79\x43\x6f\x64\x65"); qiaqsassksqiuyae: qogqewiwmwiwskgm: return $quscceoaiwasmkcy; } }
