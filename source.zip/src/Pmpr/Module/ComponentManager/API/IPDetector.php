<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b7bdc11a561             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\x74\x74\160\x3a\x2f\x2f\151\160\55\141\x70\151\x2e\x63\157\x6d\x2f\x6a\x73\x6f\x6e"; $this->ksiyskmggywgsayu("\x66\151\145\x6c\144\163", "\x31\x34\67\64\x35\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qogqewiwmwiwskgm; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto qiaqsassksqiuyae; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\156\x74\x72\x79\x43\x6f\x64\145"); qiaqsassksqiuyae: qogqewiwmwiwskgm: return $quscceoaiwasmkcy; } }
