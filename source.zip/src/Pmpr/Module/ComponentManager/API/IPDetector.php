<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab93c90ff             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\x68\164\x74\x70\72\x2f\57\x69\160\55\141\160\151\x2e\143\x6f\155\x2f\x6a\x73\157\x6e"; $this->ksiyskmggywgsayu("\x66\151\145\154\144\x73", "\x31\x34\67\64\x35\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto goeoymmqqqeeoime; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto qmiwsequckckoaei; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\x6e\x74\x72\x79\x43\x6f\144\145"); qmiwsequckckoaei: goeoymmqqqeeoime: return $quscceoaiwasmkcy; } }
