<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd8a5b9d3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class IPDetector extends API { public function __construct() { $this->domain = "\x68\x74\x74\160\x3a\57\x2f\151\x70\x2d\141\160\x69\x2e\x63\157\155\x2f\152\163\x6f\x6e"; $this->ksiyskmggywgsayu("\x66\151\x65\154\144\x73", "\x31\x34\x37\64\65\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if ($sogksuscggsicmac) { $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\x6f\x75\x6e\164\x72\171\x43\x6f\144\x65"); } } return $quscceoaiwasmkcy; } }
