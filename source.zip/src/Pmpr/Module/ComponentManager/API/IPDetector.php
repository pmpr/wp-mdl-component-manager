<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4018f4d232             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\164\164\160\72\x2f\x2f\151\160\55\141\x70\x69\56\143\157\155\57\x6a\163\157\156"; $this->ksiyskmggywgsayu("\146\151\x65\154\144\x73", "\x31\64\x37\x34\65\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qogqewiwmwiwskgm; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto qiaqsassksqiuyae; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\157\165\x6e\164\162\171\103\x6f\144\x65"); qiaqsassksqiuyae: qogqewiwmwiwskgm: return $quscceoaiwasmkcy; } }
