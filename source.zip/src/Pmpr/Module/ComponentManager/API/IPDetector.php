<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4432a54e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\x74\x74\x70\x3a\57\57\151\x70\55\x61\160\151\56\143\x6f\155\57\x6a\163\x6f\x6e"; $this->ksiyskmggywgsayu("\x66\x69\x65\154\144\163", "\x31\x34\x37\64\x35\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto goeoymmqqqeeoime; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto qmiwsequckckoaei; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\x6f\x75\x6e\164\x72\x79\x43\157\144\x65"); qmiwsequckckoaei: goeoymmqqqeeoime: return $quscceoaiwasmkcy; } }
