<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada7994f22             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\x68\x74\164\160\72\x2f\x2f\x69\x70\x2d\x61\160\x69\x2e\143\x6f\x6d\57\152\x73\x6f\156"; $this->ksiyskmggywgsayu("\x66\x69\x65\154\x64\163", "\61\64\x37\64\x35\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto egyyiccaeeiooaua; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto ooeausyowguqicuo; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\x6f\165\x6e\164\x72\171\x43\x6f\144\x65"); ooeausyowguqicuo: egyyiccaeeiooaua: return $quscceoaiwasmkcy; } }
