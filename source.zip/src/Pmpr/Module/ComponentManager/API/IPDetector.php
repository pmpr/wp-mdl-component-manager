<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a692ce391             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\x74\164\160\72\x2f\57\x69\160\55\141\x70\x69\56\x63\x6f\155\57\152\163\157\156"; $this->ksiyskmggywgsayu("\146\151\145\x6c\144\x73", "\x31\x34\x37\64\x35\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto asmecuqiyyswueqe; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto myoicgcuugciueis; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\x6f\x75\x6e\x74\162\x79\103\157\x64\145"); myoicgcuugciueis: asmecuqiyyswueqe: return $quscceoaiwasmkcy; } }
