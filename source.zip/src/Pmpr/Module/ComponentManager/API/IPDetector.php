<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b3f9cf876da             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\x74\164\x70\x3a\57\57\151\160\55\141\160\151\56\143\157\155\57\152\x73\157\156"; $this->ksiyskmggywgsayu("\x66\x69\145\154\x64\163", "\61\x34\x37\64\65\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qogqewiwmwiwskgm; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto qiaqsassksqiuyae; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\165\x6e\164\x72\x79\103\157\x64\145"); qiaqsassksqiuyae: qogqewiwmwiwskgm: return $quscceoaiwasmkcy; } }
