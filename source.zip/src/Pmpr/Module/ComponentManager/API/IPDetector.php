<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43b00aa9c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\x74\164\x70\x3a\x2f\57\151\160\x2d\141\160\151\56\143\x6f\x6d\57\152\x73\157\156"; $this->ksiyskmggywgsayu("\x66\151\145\154\x64\163", "\61\x34\67\x34\65\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto quwcqmyokicssyew; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto kiwqkcaekqqyuegq; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\165\x6e\x74\162\x79\103\157\144\x65"); kiwqkcaekqqyuegq: quwcqmyokicssyew: return $quscceoaiwasmkcy; } }
