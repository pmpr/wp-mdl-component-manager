<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66303061efad8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\164\164\x70\x3a\x2f\57\x69\160\x2d\x61\160\x69\56\x63\x6f\155\x2f\152\x73\x6f\x6e"; $this->ksiyskmggywgsayu("\146\151\145\x6c\x64\163", "\61\64\x37\64\x35\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto ygkcacsyyckescqs; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto qmeoaqmsuseueqiy; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\156\164\162\171\103\x6f\144\145"); qmeoaqmsuseueqiy: ygkcacsyyckescqs: return $quscceoaiwasmkcy; } }
