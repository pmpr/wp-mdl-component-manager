<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669f570b9bb41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\x68\x74\164\x70\72\57\57\x69\x70\x2d\x61\x70\x69\x2e\x63\157\x6d\57\x6a\x73\x6f\x6e"; $this->ksiyskmggywgsayu("\x66\x69\145\x6c\x64\163", "\61\x34\67\64\65\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto scisgsyemmsekgos; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto egyyiccaeeiooaua; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\x6f\x75\156\164\162\x79\103\x6f\144\x65"); egyyiccaeeiooaua: scisgsyemmsekgos: return $quscceoaiwasmkcy; } }
