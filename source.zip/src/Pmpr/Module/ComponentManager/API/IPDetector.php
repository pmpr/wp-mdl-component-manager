<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d713e7af9a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\x74\164\160\x3a\x2f\57\x69\x70\x2d\x61\160\x69\x2e\x63\157\155\57\152\163\157\156"; $this->ksiyskmggywgsayu("\x66\151\145\154\x64\x73", "\x31\64\67\64\65\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto egyyiccaeeiooaua; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto ooeausyowguqicuo; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\x6e\164\162\x79\103\157\x64\x65"); ooeausyowguqicuo: egyyiccaeeiooaua: return $quscceoaiwasmkcy; } }
