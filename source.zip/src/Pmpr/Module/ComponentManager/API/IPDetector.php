<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90a1d8e39             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\164\164\160\x3a\x2f\x2f\x69\x70\x2d\x61\x70\x69\x2e\143\x6f\x6d\57\152\163\157\156"; $this->ksiyskmggywgsayu("\146\151\145\154\144\163", "\x31\64\x37\64\x35\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qogqewiwmwiwskgm; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto qiaqsassksqiuyae; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\165\156\x74\162\x79\x43\157\x64\x65"); qiaqsassksqiuyae: qogqewiwmwiwskgm: return $quscceoaiwasmkcy; } }
