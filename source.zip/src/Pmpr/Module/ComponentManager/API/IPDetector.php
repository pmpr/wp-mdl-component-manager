<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8aa6ea3a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\x68\164\164\x70\x3a\x2f\57\151\160\x2d\141\x70\151\56\x63\x6f\x6d\x2f\152\163\157\156"; $this->ksiyskmggywgsayu("\146\x69\x65\x6c\144\x73", "\61\x34\x37\64\x35\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\57{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto goeoymmqqqeeoime; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto qmiwsequckckoaei; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\x75\156\x74\x72\171\103\x6f\x64\145"); qmiwsequckckoaei: goeoymmqqqeeoime: return $quscceoaiwasmkcy; } }
