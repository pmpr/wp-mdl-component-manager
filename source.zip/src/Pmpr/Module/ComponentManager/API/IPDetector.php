<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e4c033d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\x74\164\x70\72\57\57\x69\x70\55\x61\x70\151\56\143\x6f\155\x2f\x6a\163\x6f\x6e"; $this->ksiyskmggywgsayu("\146\x69\145\154\x64\x73", "\61\x34\x37\x34\x35\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto mqkmcysgoiaouiwm; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto ykomgumacooyomsk; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\143\157\165\x6e\x74\162\171\103\157\144\x65"); ykomgumacooyomsk: mqkmcysgoiaouiwm: return $quscceoaiwasmkcy; } }
