<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707f66215d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\x68\x74\164\x70\72\x2f\57\x69\160\x2d\141\160\x69\x2e\x63\157\x6d\x2f\152\163\157\x6e"; $this->ksiyskmggywgsayu("\146\151\x65\x6c\144\x73", "\61\64\67\x34\x35\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto goeoymmqqqeeoime; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto qmiwsequckckoaei; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\157\x75\x6e\164\x72\x79\x43\x6f\144\x65"); qmiwsequckckoaei: goeoymmqqqeeoime: return $quscceoaiwasmkcy; } }
