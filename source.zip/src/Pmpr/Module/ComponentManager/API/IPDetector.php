<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d5964142a0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\x68\164\164\160\x3a\x2f\x2f\x69\x70\55\x61\160\151\56\x63\x6f\x6d\57\x6a\x73\x6f\x6e"; $this->ksiyskmggywgsayu("\x66\151\x65\154\x64\163", "\61\64\67\64\x35\70"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto egyyiccaeeiooaua; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto ooeausyowguqicuo; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\x6f\165\x6e\164\162\171\x43\157\x64\145"); ooeausyowguqicuo: egyyiccaeeiooaua: return $quscceoaiwasmkcy; } }
