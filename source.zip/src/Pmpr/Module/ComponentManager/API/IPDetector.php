<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec4816940             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class IPDetector extends Common { public function __construct() { $this->domain = "\150\164\x74\160\x3a\57\57\151\x70\55\x61\160\151\x2e\143\x6f\x6d\x2f\x6a\163\x6f\156"; $this->ksiyskmggywgsayu("\x66\x69\x65\x6c\144\163", "\61\x34\x37\x34\65\x38"); parent::__construct(); } public function mcyaoicyesuysggi($kucumcusyyckayas) { $keccaugmemegoimu = $this->get("\x2f{$kucumcusyyckayas}"); $quscceoaiwasmkcy = false; if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto mqkmcysgoiaouiwm; } $sogksuscggsicmac = $this->qemyqseaomicaacs($keccaugmemegoimu); if (!$sogksuscggsicmac) { goto ykomgumacooyomsk; } $quscceoaiwasmkcy = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, "\x63\x6f\165\x6e\x74\162\x79\103\x6f\x64\145"); ykomgumacooyomsk: mqkmcysgoiaouiwm: return $quscceoaiwasmkcy; } }
