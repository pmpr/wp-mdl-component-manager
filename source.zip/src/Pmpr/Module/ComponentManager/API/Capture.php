<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b7bdc11a561             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\x74\164\160\163\x3a\57\57\x61\160\151\56\x74\x68\x75\155\142\x6e\x61\x69\154\x2e\x77\x73\x2f\x61\x70\x69\x2f\141\x62\146\x32\x38\65\x36\x61\x37\143\x38\60\x64\x30\x31\x65\142\x33\60\x64\x62\x64\x35\60\x62\67\64\x37\x32\143\x65\x35\146\63\x64\x31\70\60\x39\60\x38\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\150\165\x6d\142\156\141\x69\x6c\x2f\x67\145\164\77\165\162\154\75{$eeamcawaiqocomwy}\x26\167\x69\144\x74\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto cecuyayqoioasumi; } $aqykuigiuwmmcieu = "\x64\141\164\x61\x3a\x69\155\x61\147\145\x2f\x6a\x70\147\73\x62\x61\x73\x65\x36\x34\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); cecuyayqoioasumi: return $aqykuigiuwmmcieu; } }
