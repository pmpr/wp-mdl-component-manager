<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670da375e3820             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\x74\x74\x70\163\72\57\x2f\x61\160\151\56\x74\150\x75\155\142\156\x61\x69\154\x2e\167\163\x2f\141\160\x69\57\141\142\x66\x32\x38\x35\66\x61\67\143\x38\60\x64\x30\x31\x65\x62\x33\x30\x64\x62\x64\x35\60\x62\67\64\67\62\143\145\x35\146\x33\x64\61\70\x30\71\60\x38\64\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\x68\x75\155\x62\156\141\151\154\57\x67\145\164\x3f\x75\162\x6c\x3d{$eeamcawaiqocomwy}\46\x77\151\x64\x74\x68\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\x6d\x61\x67\145\57\x6a\160\x67"); } return $aqykuigiuwmmcieu; } }
