<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6184c6e3eb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\x74\160\163\72\57\x2f\141\x70\151\56\164\x68\x75\155\142\x6e\141\151\x6c\56\x77\x73\x2f\141\160\151\57\x61\x62\146\62\70\x35\66\x61\67\x63\70\x30\x64\x30\x31\145\x62\63\60\144\142\144\65\x30\x62\67\64\x37\x32\x63\x65\65\x66\63\x64\61\70\60\x39\60\x38\x34\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\x75\155\x62\156\141\151\154\x2f\x67\x65\164\77\165\162\154\75{$eeamcawaiqocomwy}\46\167\x69\x64\x74\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto cecuyayqoioasumi; } $aqykuigiuwmmcieu = "\x64\x61\164\141\x3a\x69\155\x61\x67\145\x2f\x6a\160\x67\x3b\142\141\163\145\x36\64\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); cecuyayqoioasumi: return $aqykuigiuwmmcieu; } }
