<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab93c90ff             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\x74\x70\163\72\x2f\57\x61\x70\x69\56\164\150\165\155\142\x6e\141\x69\154\56\x77\163\57\x61\x70\x69\57\141\142\146\62\x38\x35\66\141\67\x63\x38\x30\x64\60\61\x65\x62\x33\x30\x64\142\x64\x35\x30\x62\x37\x34\x37\62\x63\145\x35\x66\63\144\x31\70\60\x39\x30\70\64\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\x68\x75\x6d\142\x6e\x61\151\154\x2f\147\x65\164\77\x75\162\x6c\75{$eeamcawaiqocomwy}\x26\x77\x69\x64\x74\x68\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qgegkeomwscwwiuw; } $aqykuigiuwmmcieu = "\144\141\164\x61\72\151\x6d\141\x67\145\57\152\x70\x67\73\x62\x61\x73\145\66\x34\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); qgegkeomwscwwiuw: return $aqykuigiuwmmcieu; } }
