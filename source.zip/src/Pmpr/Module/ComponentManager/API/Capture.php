<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678aa15347d4f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\164\164\x70\163\72\x2f\57\141\160\151\x2e\x74\150\165\155\x62\x6e\x61\151\154\x2e\x77\163\57\x61\160\x69\x2f\x61\142\x66\x32\70\x35\66\141\x37\x63\70\x30\144\60\61\x65\x62\63\x30\144\142\x64\65\60\142\x37\64\67\x32\x63\145\65\x66\63\x64\x31\x38\60\x39\x30\x38\64\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\150\165\x6d\x62\156\141\x69\154\x2f\x67\x65\x74\x3f\165\x72\x6c\75{$eeamcawaiqocomwy}\46\167\x69\x64\x74\150\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\x61\x67\145\57\x6a\160\x67"); } return $aqykuigiuwmmcieu; } }
