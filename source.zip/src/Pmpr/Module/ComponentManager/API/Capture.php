<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4432a54e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\164\160\x73\72\x2f\x2f\141\x70\151\x2e\x74\150\x75\155\142\156\x61\151\154\56\167\163\x2f\141\x70\151\57\141\142\146\x32\x38\65\x36\141\67\x63\x38\60\x64\x30\61\x65\142\x33\x30\x64\x62\x64\65\x30\142\x37\x34\x37\62\x63\145\65\x66\63\x64\61\x38\60\x39\x30\70\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\x68\x75\155\x62\x6e\141\151\x6c\x2f\147\x65\164\77\x75\x72\154\x3d{$eeamcawaiqocomwy}\46\x77\x69\144\x74\150\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qgegkeomwscwwiuw; } $aqykuigiuwmmcieu = "\x64\x61\x74\141\x3a\151\155\141\147\x65\57\152\160\147\x3b\x62\141\163\x65\66\x34\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); qgegkeomwscwwiuw: return $aqykuigiuwmmcieu; } }
