<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d5964142a0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\x74\x70\163\x3a\x2f\x2f\141\x70\151\x2e\164\150\165\155\142\156\x61\151\154\x2e\167\163\x2f\x61\160\151\x2f\x61\x62\146\x32\x38\x35\66\x61\x37\x63\70\60\x64\x30\x31\x65\142\63\x30\144\x62\144\65\x30\142\x37\x34\x37\62\143\x65\x35\x66\x33\x64\61\70\x30\x39\x30\70\64\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\x68\165\155\142\156\x61\x69\154\57\x67\x65\164\77\x75\162\x6c\75{$eeamcawaiqocomwy}\x26\x77\151\x64\164\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto gkyawqqcmigqgaiq; } $aqykuigiuwmmcieu = "\144\141\x74\141\72\x69\x6d\141\x67\x65\57\152\x70\147\73\142\141\x73\x65\66\64\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); gkyawqqcmigqgaiq: return $aqykuigiuwmmcieu; } }
