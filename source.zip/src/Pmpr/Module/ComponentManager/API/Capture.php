<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec4816940             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\x74\x74\160\163\72\57\57\x61\x70\x69\x2e\x74\x68\x75\x6d\x62\156\141\151\x6c\x2e\167\163\57\141\x70\x69\x2f\141\x62\146\62\x38\x35\x36\141\67\x63\x38\x30\x64\x30\x31\x65\142\63\x30\x64\x62\144\65\60\x62\67\x34\67\x32\x63\x65\x35\x66\x33\144\x31\x38\x30\x39\60\x38\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\x75\155\142\156\x61\x69\154\x2f\147\145\x74\77\165\x72\x6c\75{$eeamcawaiqocomwy}\x26\167\x69\144\164\x68\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto kosaqwikueyksqmw; } $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\141\x67\x65\x2f\x6a\x70\x67"); kosaqwikueyksqmw: return $aqykuigiuwmmcieu; } }
