<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43b00aa9c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\164\x70\163\72\57\x2f\x61\x70\x69\x2e\164\x68\165\155\142\x6e\141\x69\x6c\x2e\x77\163\x2f\x61\160\151\x2f\141\x62\x66\62\x38\65\x36\141\x37\x63\x38\60\144\60\x31\x65\x62\63\x30\x64\142\x64\x35\60\x62\67\x34\x37\x32\143\x65\x35\146\x33\144\x31\x38\60\x39\x30\x38\x34\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\x75\x6d\x62\x6e\x61\x69\x6c\57\147\145\x74\x3f\165\x72\154\x3d{$eeamcawaiqocomwy}\x26\167\x69\x64\x74\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qsygcycwieukkgwc; } $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\x6d\141\x67\145\x2f\152\160\147"); qsygcycwieukkgwc: return $aqykuigiuwmmcieu; } }
