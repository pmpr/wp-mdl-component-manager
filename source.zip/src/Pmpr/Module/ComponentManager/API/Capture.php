<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b3f9cf876da             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\164\x74\160\x73\x3a\x2f\57\141\160\151\56\164\150\165\x6d\x62\156\x61\x69\154\x2e\x77\163\x2f\x61\x70\151\x2f\141\142\x66\x32\70\65\x36\141\x37\143\x38\x30\x64\x30\61\145\142\63\60\144\142\x64\x35\x30\142\x37\x34\67\x32\143\x65\x35\146\x33\144\61\70\60\71\60\x38\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\150\x75\x6d\142\156\x61\x69\x6c\57\147\x65\x74\x3f\x75\162\154\75{$eeamcawaiqocomwy}\x26\167\151\x64\164\x68\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto cecuyayqoioasumi; } $aqykuigiuwmmcieu = "\x64\141\x74\x61\x3a\151\x6d\x61\147\x65\x2f\152\x70\147\x3b\x62\141\163\x65\66\64\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); cecuyayqoioasumi: return $aqykuigiuwmmcieu; } }
