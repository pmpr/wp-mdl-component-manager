<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66c31d43a4c0d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\164\164\x70\x73\x3a\57\x2f\x61\x70\x69\x2e\164\x68\x75\155\x62\156\141\x69\x6c\56\167\163\x2f\x61\160\x69\x2f\141\142\146\x32\x38\65\66\x61\x37\x63\70\60\x64\x30\61\145\142\x33\x30\144\x62\144\65\60\142\x37\x34\67\x32\143\145\x35\x66\x33\144\61\x38\60\x39\x30\x38\64\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\x68\x75\155\x62\x6e\141\151\154\x2f\x67\145\x74\77\x75\162\154\x3d{$eeamcawaiqocomwy}\46\x77\151\x64\164\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto cecuyayqoioasumi; } $aqykuigiuwmmcieu = "\x64\x61\164\141\x3a\151\155\x61\147\x65\x2f\152\x70\x67\x3b\x62\141\x73\x65\66\x34\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); cecuyayqoioasumi: return $aqykuigiuwmmcieu; } }
