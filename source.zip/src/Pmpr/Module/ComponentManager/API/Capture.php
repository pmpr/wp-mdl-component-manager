<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669eebabccbcc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\x74\x74\160\x73\x3a\x2f\57\x61\x70\x69\x2e\164\150\165\155\142\x6e\x61\151\154\56\x77\x73\57\x61\x70\x69\57\141\142\x66\62\70\65\x36\141\x37\143\x38\x30\x64\x30\61\145\x62\63\60\x64\142\144\x35\x30\142\x37\x34\67\62\x63\145\x35\x66\63\x64\61\70\x30\x39\x30\x38\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\150\x75\155\142\156\141\x69\154\x2f\x67\145\x74\x3f\x75\162\154\x3d{$eeamcawaiqocomwy}\x26\x77\x69\x64\164\150\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto ooeausyowguqicuo; } $aqykuigiuwmmcieu = "\144\141\x74\x61\x3a\x69\x6d\x61\147\x65\x2f\152\x70\x67\x3b\x62\141\163\x65\66\64\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); ooeausyowguqicuo: return $aqykuigiuwmmcieu; } }
