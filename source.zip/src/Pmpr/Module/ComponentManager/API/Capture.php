<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6678838b736c8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\x74\x70\163\x3a\x2f\x2f\141\160\151\56\x74\150\165\x6d\x62\156\x61\151\154\x2e\167\x73\x2f\141\x70\x69\x2f\x61\x62\146\x32\x38\65\x36\x61\67\x63\70\60\x64\x30\61\145\142\x33\x30\144\x62\144\x35\60\x62\x37\x34\67\62\x63\x65\x35\146\63\x64\61\x38\x30\x39\x30\70\x34\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\150\165\155\142\x6e\x61\151\x6c\57\147\145\164\x3f\165\x72\x6c\75{$eeamcawaiqocomwy}\x26\x77\151\144\164\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qgegkeomwscwwiuw; } $aqykuigiuwmmcieu = "\144\x61\164\141\x3a\x69\155\141\x67\x65\x2f\152\x70\x67\73\x62\x61\x73\x65\66\64\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); qgegkeomwscwwiuw: return $aqykuigiuwmmcieu; } }
