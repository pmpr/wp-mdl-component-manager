<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56be6e3a1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\164\x74\x70\163\x3a\57\57\x61\x70\151\x2e\164\150\165\155\x62\156\x61\151\154\56\167\x73\57\141\160\151\x2f\x61\142\146\62\x38\65\x36\x61\x37\x63\x38\x30\x64\60\x31\x65\142\63\60\x64\142\144\65\60\142\x37\64\x37\x32\x63\145\x35\146\x33\x64\61\x38\x30\x39\60\x38\64\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\x68\x75\155\x62\156\x61\151\154\x2f\147\145\x74\x3f\165\x72\154\x3d{$eeamcawaiqocomwy}\x26\x77\x69\x64\164\150\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto cecuyayqoioasumi; } $aqykuigiuwmmcieu = "\x64\x61\x74\x61\x3a\151\155\x61\147\x65\57\x6a\x70\x67\x3b\x62\x61\x73\145\x36\64\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); cecuyayqoioasumi: return $aqykuigiuwmmcieu; } }
