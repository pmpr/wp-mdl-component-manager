<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e4c033d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\164\160\163\x3a\57\57\141\160\x69\x2e\x74\x68\x75\x6d\x62\156\x61\151\154\x2e\x77\163\x2f\141\x70\151\x2f\141\x62\146\x32\x38\65\66\x61\67\143\70\60\x64\x30\x31\145\x62\63\x30\x64\x62\x64\65\60\x62\67\64\67\62\143\x65\65\146\63\144\61\70\x30\71\x30\70\64\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\x68\165\x6d\142\x6e\141\151\154\x2f\147\145\164\x3f\x75\162\x6c\x3d{$eeamcawaiqocomwy}\x26\x77\151\144\164\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto kosaqwikueyksqmw; } $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\141\147\145\57\x6a\x70\147"); kosaqwikueyksqmw: return $aqykuigiuwmmcieu; } }
