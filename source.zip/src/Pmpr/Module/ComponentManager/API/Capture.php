<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f0875a04             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\x74\x70\x73\72\57\x2f\x61\160\x69\x2e\164\150\165\x6d\x62\156\141\x69\x6c\56\x77\163\57\141\x70\151\x2f\x61\142\x66\62\70\65\66\141\x37\x63\x38\x30\144\60\x31\145\142\63\x30\x64\142\x64\x35\60\x62\67\x34\67\62\143\145\65\146\63\x64\61\x38\x30\71\60\x38\x34\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\x68\x75\155\x62\x6e\x61\151\154\57\147\x65\x74\x3f\165\162\154\x3d{$eeamcawaiqocomwy}\x26\167\x69\x64\x74\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto cecuyayqoioasumi; } $aqykuigiuwmmcieu = "\144\x61\164\141\72\151\155\x61\x67\145\57\152\x70\147\x3b\142\x61\x73\x65\x36\x34\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); cecuyayqoioasumi: return $aqykuigiuwmmcieu; } }
