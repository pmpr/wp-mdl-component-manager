<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6623b6b7c45dc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\x74\164\160\163\72\x2f\57\141\x70\x69\x2e\164\x68\x75\x6d\x62\156\141\x69\154\56\x77\x73\57\141\160\x69\57\x61\x62\146\62\x38\x35\x36\x61\67\143\70\60\x64\x30\x31\x65\142\63\x30\x64\x62\144\x35\60\142\67\64\x37\62\143\145\65\146\x33\144\61\70\x30\71\60\x38\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\x68\x75\155\x62\x6e\141\x69\x6c\57\x67\145\164\x3f\x75\162\x6c\x3d{$eeamcawaiqocomwy}\x26\167\151\144\x74\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto ickcmqoiosquugwe; } $aqykuigiuwmmcieu = "\144\x61\x74\x61\72\151\155\141\x67\145\x2f\x6a\160\147\73\142\141\163\x65\x36\64\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); ickcmqoiosquugwe: return $aqykuigiuwmmcieu; } }
