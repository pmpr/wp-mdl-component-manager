<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd8a5b9d3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\164\164\160\x73\72\57\x2f\x61\160\x69\56\x74\150\x75\x6d\142\x6e\141\x69\x6c\x2e\167\163\57\x61\x70\151\x2f\x61\142\x66\62\70\x35\x36\141\x37\x63\x38\60\144\x30\x31\x65\x62\x33\x30\144\142\144\65\60\x62\x37\x34\67\62\143\145\x35\146\63\x64\x31\x38\60\x39\x30\x38\x34\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\x68\x75\x6d\142\x6e\x61\x69\x6c\x2f\x67\x65\x74\x3f\165\162\x6c\x3d{$eeamcawaiqocomwy}\46\x77\151\x64\x74\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\155\x61\x67\x65\x2f\x6a\x70\147"); } return $aqykuigiuwmmcieu; } }
