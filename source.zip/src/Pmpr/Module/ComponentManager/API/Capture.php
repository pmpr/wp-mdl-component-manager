<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d713e7af9a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\x74\x70\163\x3a\57\x2f\x61\160\151\56\164\x68\x75\155\x62\156\141\x69\154\x2e\x77\x73\x2f\x61\x70\151\57\141\x62\x66\62\x38\x35\x36\141\67\x63\x38\x30\x64\x30\61\x65\x62\x33\60\144\x62\x64\x35\60\x62\67\x34\67\62\x63\x65\65\x66\63\x64\x31\x38\x30\71\x30\x38\64\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\150\x75\155\x62\x6e\141\151\x6c\x2f\147\x65\164\77\165\x72\x6c\x3d{$eeamcawaiqocomwy}\46\x77\x69\x64\x74\150\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto gkyawqqcmigqgaiq; } $aqykuigiuwmmcieu = "\x64\141\x74\141\72\151\155\141\x67\145\57\x6a\x70\147\x3b\x62\141\163\145\x36\64\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); gkyawqqcmigqgaiq: return $aqykuigiuwmmcieu; } }
