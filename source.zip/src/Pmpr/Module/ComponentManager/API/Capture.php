<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce54af610c2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\164\160\163\x3a\57\x2f\141\160\x69\56\x74\x68\165\x6d\142\x6e\141\151\154\56\x77\163\57\141\160\151\x2f\141\142\146\x32\70\x35\x36\141\x37\143\x38\x30\144\x30\61\145\x62\x33\60\144\x62\144\x35\x30\x62\x37\x34\x37\x32\x63\x65\65\x66\x33\144\x31\70\60\71\60\x38\x34\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\x75\155\142\x6e\141\151\154\57\147\x65\164\x3f\x75\x72\x6c\x3d{$eeamcawaiqocomwy}\46\x77\x69\144\x74\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto cecuyayqoioasumi; } $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\x6d\141\147\x65\57\152\160\x67"); cecuyayqoioasumi: return $aqykuigiuwmmcieu; } }
