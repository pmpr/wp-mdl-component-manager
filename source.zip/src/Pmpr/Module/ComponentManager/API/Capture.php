<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67abce891b505             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\164\164\x70\x73\x3a\57\x2f\x61\x70\151\x2e\164\x68\x75\155\142\156\x61\151\x6c\x2e\167\163\57\141\160\151\x2f\x61\142\x66\62\70\65\66\141\x37\143\x38\60\144\x30\61\x65\142\x33\x30\x64\142\x64\x35\60\142\x37\64\67\x32\x63\145\x35\x66\63\x64\61\70\60\71\60\70\64\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\x75\x6d\142\156\x61\x69\x6c\57\147\145\x74\x3f\165\162\x6c\75{$eeamcawaiqocomwy}\x26\167\x69\144\164\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\141\x67\145\x2f\152\160\x67"); } return $aqykuigiuwmmcieu; } }
