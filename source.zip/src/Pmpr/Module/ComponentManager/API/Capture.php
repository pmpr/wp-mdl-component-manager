<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d563249fee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\x74\160\x73\x3a\57\57\141\160\151\56\164\x68\165\155\x62\156\x61\151\x6c\x2e\167\163\x2f\x61\160\x69\57\x61\142\x66\x32\70\65\66\x61\67\x63\70\x30\x64\60\x31\145\x62\63\x30\144\x62\144\x35\x30\x62\x37\64\67\62\143\145\65\x66\63\x64\x31\x38\60\71\x30\x38\64\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\165\x6d\142\156\141\x69\x6c\x2f\147\145\x74\77\165\x72\x6c\75{$eeamcawaiqocomwy}\x26\167\x69\x64\x74\150\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto gkyawqqcmigqgaiq; } $aqykuigiuwmmcieu = "\x64\141\x74\141\x3a\x69\x6d\141\x67\x65\57\x6a\x70\147\73\x62\x61\163\x65\66\x34\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); gkyawqqcmigqgaiq: return $aqykuigiuwmmcieu; } }
