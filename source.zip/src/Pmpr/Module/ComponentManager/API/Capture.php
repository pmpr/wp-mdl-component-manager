<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a692ce391             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\164\164\160\x73\x3a\57\57\x61\x70\151\x2e\164\150\x75\155\142\x6e\x61\151\x6c\56\x77\x73\57\x61\160\151\x2f\x61\x62\x66\x32\70\65\x36\141\67\143\70\60\144\60\x31\x65\x62\x33\x30\x64\x62\x64\65\x30\x62\67\x34\67\x32\143\x65\65\146\63\x64\61\70\60\x39\x30\70\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\x68\165\x6d\142\x6e\141\x69\x6c\57\147\x65\x74\77\x75\162\154\75{$eeamcawaiqocomwy}\46\x77\x69\144\x74\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qwigomakwmyiwkgo; } $aqykuigiuwmmcieu = "\144\141\164\x61\72\151\x6d\x61\147\x65\57\152\x70\x67\73\x62\141\163\x65\66\x34\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); qwigomakwmyiwkgo: return $aqykuigiuwmmcieu; } }
