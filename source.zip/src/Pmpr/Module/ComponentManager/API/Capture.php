<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681075957227             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\164\160\x73\x3a\57\x2f\x61\160\151\56\164\150\x75\x6d\142\x6e\141\x69\154\x2e\x77\163\x2f\141\x70\x69\x2f\141\x62\146\x32\70\65\66\141\x37\143\70\60\x64\x30\x31\x65\142\63\x30\x64\142\144\x35\x30\x62\x37\64\x37\x32\143\145\65\x66\63\144\x31\70\60\71\x30\70\x34\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\x68\x75\155\142\156\141\x69\154\x2f\x67\x65\x74\x3f\165\x72\x6c\x3d{$eeamcawaiqocomwy}\x26\167\151\x64\164\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qgegkeomwscwwiuw; } $aqykuigiuwmmcieu = "\144\x61\x74\141\72\151\x6d\141\147\x65\x2f\152\x70\x67\x3b\x62\x61\x73\145\x36\x34\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); qgegkeomwscwwiuw: return $aqykuigiuwmmcieu; } }
