<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67235726863c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\x68\164\164\x70\163\x3a\x2f\x2f\141\x70\x69\x2e\164\x68\165\x6d\142\x6e\x61\x69\154\56\167\163\57\141\x70\151\x2f\141\142\146\62\70\x35\66\x61\x37\x63\70\60\x64\60\x31\145\x62\x33\x30\144\x62\144\x35\x30\x62\67\64\x37\x32\x63\x65\x35\146\63\144\x31\x38\x30\71\60\x38\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\165\155\x62\x6e\141\151\x6c\x2f\147\145\x74\x3f\x75\162\x6c\75{$eeamcawaiqocomwy}\x26\167\151\x64\x74\150\75{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\x6d\x61\147\x65\x2f\152\160\x67"); } return $aqykuigiuwmmcieu; } }
