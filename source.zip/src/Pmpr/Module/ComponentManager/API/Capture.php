<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661d2758990bd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\164\164\x70\x73\72\x2f\x2f\141\160\151\56\x74\150\x75\x6d\142\x6e\x61\151\154\x2e\x77\163\57\141\x70\x69\x2f\x61\x62\146\62\x38\x35\66\141\x37\x63\70\60\144\x30\x31\x65\142\63\60\x64\142\144\x35\x30\x62\67\x34\67\62\x63\x65\65\x66\x33\144\x31\70\x30\x39\x30\70\x34\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\x75\155\x62\156\141\x69\154\x2f\x67\x65\x74\77\x75\162\154\x3d{$eeamcawaiqocomwy}\46\167\151\144\164\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto kicwiowcogmauwiy; } $aqykuigiuwmmcieu = "\144\x61\x74\x61\72\151\x6d\x61\x67\145\x2f\x6a\160\147\x3b\x62\141\163\145\66\x34\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); kicwiowcogmauwiy: return $aqykuigiuwmmcieu; } }
