<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d89e69c831             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\x74\164\160\x73\x3a\57\x2f\141\x70\x69\x2e\x74\x68\x75\155\142\x6e\x61\x69\x6c\x2e\x77\163\x2f\x61\x70\x69\57\141\142\x66\x32\70\x35\x36\141\x37\x63\70\60\x64\x30\61\145\142\63\60\144\x62\144\65\60\x62\67\64\x37\62\143\x65\65\146\x33\144\x31\70\x30\x39\60\70\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\x75\x6d\142\156\141\x69\x6c\x2f\x67\x65\x74\x3f\165\x72\x6c\75{$eeamcawaiqocomwy}\46\x77\x69\144\x74\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\151\155\x61\x67\x65\x2f\152\x70\147"); } return $aqykuigiuwmmcieu; } }
