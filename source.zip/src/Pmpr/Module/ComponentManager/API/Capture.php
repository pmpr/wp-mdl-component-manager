<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d7322bfbb4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\164\160\x73\x3a\57\57\x61\160\151\x2e\164\x68\165\155\x62\x6e\141\151\154\x2e\167\163\57\x61\160\151\x2f\x61\x62\x66\x32\x38\x35\x36\x61\x37\x63\x38\x30\x64\60\x31\145\x62\x33\x30\x64\142\x64\x35\60\x62\x37\x34\x37\62\x63\x65\x35\146\63\144\61\x38\x30\71\60\x38\64\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\x68\x75\155\142\156\x61\151\x6c\57\147\145\x74\77\x75\162\x6c\x3d{$eeamcawaiqocomwy}\46\x77\151\144\x74\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto gkyawqqcmigqgaiq; } $aqykuigiuwmmcieu = "\x64\141\x74\x61\x3a\x69\155\x61\147\145\57\152\x70\x67\x3b\142\141\163\x65\66\x34\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); gkyawqqcmigqgaiq: return $aqykuigiuwmmcieu; } }
