<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4018f4d232             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\164\160\163\72\57\x2f\x61\160\x69\x2e\x74\x68\165\155\x62\x6e\141\x69\x6c\x2e\167\163\57\x61\x70\x69\x2f\x61\x62\146\x32\x38\x35\x36\141\67\x63\x38\60\144\60\61\x65\x62\x33\x30\x64\x62\x64\x35\x30\x62\x37\64\x37\62\x63\145\x35\x66\x33\x64\61\x38\x30\x39\x30\x38\x34\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\165\155\x62\x6e\x61\x69\154\57\x67\x65\x74\x3f\x75\162\154\x3d{$eeamcawaiqocomwy}\x26\167\x69\x64\164\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto cecuyayqoioasumi; } $aqykuigiuwmmcieu = "\144\x61\x74\x61\72\151\x6d\x61\x67\145\57\x6a\x70\x67\73\x62\x61\163\145\x36\64\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); cecuyayqoioasumi: return $aqykuigiuwmmcieu; } }
