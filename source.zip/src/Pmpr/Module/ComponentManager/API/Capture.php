<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8aa6ea3a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\x74\164\x70\x73\72\x2f\x2f\x61\x70\x69\56\164\150\165\x6d\142\x6e\141\151\154\56\167\x73\57\141\160\151\57\x61\142\x66\62\70\x35\66\x61\67\x63\70\60\144\x30\61\145\142\x33\60\144\142\144\65\60\x62\67\x34\67\62\x63\145\x35\146\x33\x64\x31\x38\60\x39\x30\x38\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\x68\x75\x6d\142\x6e\x61\151\x6c\x2f\x67\x65\164\x3f\x75\162\154\x3d{$eeamcawaiqocomwy}\46\167\x69\144\x74\150\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qgegkeomwscwwiuw; } $aqykuigiuwmmcieu = "\x64\141\164\x61\72\151\x6d\x61\147\145\x2f\152\160\147\x3b\x62\x61\x73\x65\66\64\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); qgegkeomwscwwiuw: return $aqykuigiuwmmcieu; } }
