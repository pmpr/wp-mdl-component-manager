<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ab90a1d8e39             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\x74\160\163\72\x2f\x2f\x61\x70\x69\56\164\x68\165\x6d\142\x6e\141\x69\154\x2e\x77\163\57\141\160\151\57\141\x62\146\62\70\65\x36\141\67\x63\70\60\x64\60\61\145\x62\x33\60\144\x62\x64\x35\60\142\67\64\x37\x32\x63\x65\65\x66\x33\x64\61\70\x30\71\x30\x38\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\165\155\x62\156\x61\x69\x6c\x2f\147\145\x74\77\165\162\x6c\x3d{$eeamcawaiqocomwy}\x26\x77\151\144\164\150\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto cecuyayqoioasumi; } $aqykuigiuwmmcieu = "\144\141\164\x61\72\151\x6d\141\147\145\x2f\x6a\160\147\x3b\142\141\x73\145\x36\x34\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); cecuyayqoioasumi: return $aqykuigiuwmmcieu; } }
