<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc52a008a7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; use Pmpr\Common\Foundation\API\API; class Capture extends API { public function __construct() { $this->domain = "\150\164\164\160\x73\72\x2f\x2f\x61\x70\x69\56\164\150\165\x6d\x62\x6e\141\x69\x6c\56\167\163\57\x61\160\151\x2f\141\x62\146\x32\70\65\x36\141\x37\143\70\x30\144\60\x31\x65\x62\x33\60\x64\142\144\65\60\x62\67\64\67\x32\x63\145\x35\x66\63\x64\x31\70\60\71\60\x38\x34\60\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\x68\165\155\142\156\x61\x69\x6c\x2f\x67\x65\164\x3f\165\x72\x6c\x3d{$eeamcawaiqocomwy}\x26\167\151\x64\x74\x68\x3d{$qeswwaqqsyymqawg}"); if ($this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\x61\x67\145\x2f\152\x70\x67"); } return $aqykuigiuwmmcieu; } }
