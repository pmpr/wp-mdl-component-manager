<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c358d714aa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\x74\164\160\163\x3a\x2f\57\x61\160\151\56\164\x68\x75\155\142\156\141\x69\154\x2e\x77\163\57\x61\160\151\57\x61\x62\146\x32\70\65\66\141\x37\143\x38\60\x64\x30\61\x65\x62\63\x30\144\x62\x64\x35\x30\142\67\64\67\62\143\x65\x35\146\63\x64\x31\x38\x30\x39\60\x38\x34\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\150\165\x6d\142\x6e\141\151\x6c\x2f\147\145\164\77\x75\x72\x6c\75{$eeamcawaiqocomwy}\x26\x77\x69\x64\x74\x68\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto gkyawqqcmigqgaiq; } $aqykuigiuwmmcieu = "\144\x61\x74\x61\x3a\x69\155\x61\147\145\57\152\160\x67\x3b\142\x61\x73\145\66\64\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); gkyawqqcmigqgaiq: return $aqykuigiuwmmcieu; } }
