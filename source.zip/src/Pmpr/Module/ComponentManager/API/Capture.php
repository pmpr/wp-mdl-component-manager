<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707f66215d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\x74\160\163\x3a\57\57\141\x70\151\56\164\150\165\155\x62\156\141\x69\154\56\x77\163\57\141\x70\x69\57\x61\142\146\x32\70\x35\x36\141\x37\143\70\x30\144\x30\x31\x65\142\63\60\x64\142\x64\x35\x30\142\x37\x34\67\62\143\145\x35\146\x33\144\x31\70\60\71\x30\70\64\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\164\x68\165\155\142\156\x61\x69\154\x2f\147\145\164\77\165\162\x6c\x3d{$eeamcawaiqocomwy}\46\x77\x69\x64\164\x68\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qgegkeomwscwwiuw; } $aqykuigiuwmmcieu = "\144\141\x74\141\x3a\x69\155\x61\147\145\57\x6a\x70\x67\x3b\142\141\x73\145\x36\64\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); qgegkeomwscwwiuw: return $aqykuigiuwmmcieu; } }
