<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66303061efad8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\164\x74\160\x73\72\57\x2f\141\160\x69\x2e\x74\x68\x75\155\x62\156\x61\151\154\56\167\163\57\141\x70\x69\57\141\142\146\62\70\65\66\141\67\143\70\x30\144\x30\61\145\x62\63\60\144\x62\x64\x35\60\x62\x37\64\x37\x32\x63\145\65\146\63\144\x31\x38\60\71\60\x38\64\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\x74\x68\x75\x6d\142\x6e\x61\151\154\57\x67\x65\164\x3f\x75\162\x6c\x3d{$eeamcawaiqocomwy}\46\x77\151\x64\x74\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto ickcmqoiosquugwe; } $aqykuigiuwmmcieu = "\144\141\x74\x61\x3a\151\x6d\x61\147\x65\57\152\160\147\73\142\x61\x73\145\66\64\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); ickcmqoiosquugwe: return $aqykuigiuwmmcieu; } }
