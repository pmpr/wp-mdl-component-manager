<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada7994f22             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\164\x74\160\x73\x3a\57\x2f\x61\x70\x69\x2e\x74\x68\x75\x6d\142\x6e\141\x69\154\x2e\167\163\x2f\x61\160\x69\x2f\x61\142\x66\x32\x38\x35\x36\141\x37\x63\70\x30\x64\60\x31\145\142\63\60\x64\x62\x64\65\60\142\x37\64\x37\x32\x63\145\65\x66\63\144\x31\70\60\x39\x30\x38\64\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\150\x75\155\x62\x6e\141\x69\154\x2f\x67\145\x74\77\165\x72\154\x3d{$eeamcawaiqocomwy}\46\167\x69\x64\x74\150\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto gkyawqqcmigqgaiq; } $aqykuigiuwmmcieu = "\x64\x61\x74\x61\x3a\x69\x6d\x61\x67\145\x2f\152\160\x67\x3b\x62\141\163\145\x36\64\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); gkyawqqcmigqgaiq: return $aqykuigiuwmmcieu; } }
