<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400c19633a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\x74\164\160\x73\72\x2f\x2f\x61\x70\151\56\x74\150\165\x6d\x62\156\x61\151\x6c\x2e\167\x73\57\141\x70\x69\x2f\x61\142\146\62\70\x35\66\141\67\x63\x38\60\144\60\61\145\x62\63\60\x64\x62\x64\65\x30\x62\x37\64\67\x32\x63\145\65\x66\63\144\61\70\60\71\60\x38\64\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\x75\x6d\142\156\141\151\154\x2f\147\x65\x74\x3f\165\162\154\x3d{$eeamcawaiqocomwy}\46\167\x69\x64\164\150\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto qgegkeomwscwwiuw; } $aqykuigiuwmmcieu = "\x64\141\x74\141\72\x69\155\141\147\145\57\152\160\x67\x3b\x62\141\163\x65\66\x34\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); qgegkeomwscwwiuw: return $aqykuigiuwmmcieu; } }
