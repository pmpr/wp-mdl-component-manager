<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c4445875de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\x74\x70\x73\x3a\57\57\x61\160\x69\x2e\164\x68\165\155\142\156\x61\x69\154\x2e\x77\x73\57\141\160\x69\x2f\141\x62\146\x32\70\x35\66\x61\x37\x63\70\60\144\x30\61\145\142\63\x30\x64\x62\x64\x35\60\x62\67\64\x37\62\x63\x65\x35\146\63\x64\x31\x38\x30\71\60\x38\x34\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\150\165\x6d\x62\x6e\141\151\x6c\57\x67\145\x74\x3f\165\162\x6c\x3d{$eeamcawaiqocomwy}\46\x77\x69\144\x74\150\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto gkyawqqcmigqgaiq; } $aqykuigiuwmmcieu = "\144\141\164\x61\x3a\x69\x6d\x61\147\x65\57\152\x70\147\x3b\142\141\x73\145\66\x34\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); gkyawqqcmigqgaiq: return $aqykuigiuwmmcieu; } }
