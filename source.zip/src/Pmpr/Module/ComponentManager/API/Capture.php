<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce117a11525             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\x74\160\x73\x3a\x2f\57\141\160\151\56\x74\x68\x75\x6d\142\156\x61\x69\x6c\x2e\167\x73\57\141\160\151\57\x61\142\146\x32\x38\65\66\x61\x37\x63\x38\60\x64\x30\x31\145\142\x33\60\x64\x62\x64\x35\60\142\67\64\x37\x32\x63\145\x35\146\63\144\61\70\x30\x39\60\70\x34\60\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\x68\x75\x6d\x62\x6e\141\151\154\57\x67\x65\164\77\x75\162\154\75{$eeamcawaiqocomwy}\46\x77\151\144\x74\x68\75{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto cecuyayqoioasumi; } $aqykuigiuwmmcieu = $this->caokeucsksukesyo()->owgcciayoweymuws()->uiyouwwuscecumsg($this->saegmcouuukeykgi($keccaugmemegoimu), "\x69\155\141\147\145\x2f\x6a\x70\147"); cecuyayqoioasumi: return $aqykuigiuwmmcieu; } }
