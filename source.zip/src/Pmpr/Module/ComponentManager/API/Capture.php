<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669f570b9bb41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\150\x74\x74\x70\163\x3a\x2f\x2f\141\x70\151\56\164\150\x75\x6d\x62\x6e\x61\151\x6c\56\x77\163\x2f\141\x70\151\57\141\x62\x66\62\70\65\66\141\x37\143\70\x30\144\60\61\x65\x62\x33\60\x64\x62\144\65\60\142\67\64\x37\62\x63\x65\65\x66\63\x64\x31\70\x30\71\60\x38\x34\x30\x62"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\57\164\x68\165\155\142\156\141\151\x6c\57\147\x65\x74\77\165\x72\154\x3d{$eeamcawaiqocomwy}\46\167\151\144\164\x68\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto ooeausyowguqicuo; } $aqykuigiuwmmcieu = "\144\x61\x74\141\x3a\151\155\x61\x67\145\57\x6a\160\147\x3b\142\141\163\145\66\x34\x2c" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); ooeausyowguqicuo: return $aqykuigiuwmmcieu; } }
