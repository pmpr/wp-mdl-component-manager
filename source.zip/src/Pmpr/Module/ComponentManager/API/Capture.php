<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b939727b32d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\API; class Capture extends Common { public function __construct() { $this->domain = "\x68\x74\x74\160\163\72\x2f\57\141\160\151\56\x74\x68\165\155\x62\x6e\141\x69\x6c\56\x77\163\x2f\141\x70\151\57\141\142\146\x32\70\x35\66\141\x37\x63\70\60\144\x30\x31\x65\142\x33\x30\x64\x62\x64\65\60\142\x37\64\x37\62\x63\145\65\146\63\144\61\70\60\71\x30\70\x34\x30\142"; parent::__construct(); } public function qikaamumksmwoeqi($eeamcawaiqocomwy, $qeswwaqqsyymqawg = 800) { $eeamcawaiqocomwy = esc_url($eeamcawaiqocomwy); $aqykuigiuwmmcieu = false; $keccaugmemegoimu = $this->get("\x2f\x74\150\165\x6d\142\x6e\141\x69\x6c\x2f\x67\x65\164\77\x75\x72\x6c\x3d{$eeamcawaiqocomwy}\46\167\x69\x64\x74\150\x3d{$qeswwaqqsyymqawg}"); if (!$this->occymigcemkqucuw($keccaugmemegoimu, $uamcoiueqaamsqma)) { goto cecuyayqoioasumi; } $aqykuigiuwmmcieu = "\144\x61\x74\141\x3a\x69\x6d\x61\147\x65\57\x6a\160\147\73\x62\x61\163\x65\66\64\54" . base64_encode($this->saegmcouuukeykgi($keccaugmemegoimu)); cecuyayqoioasumi: return $aqykuigiuwmmcieu; } }
