<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668dab93c90ff             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Model; use Pmpr\Module\ComponentManager\Container; class Model extends Container { public function mameiwsayuyquoeq() { Report::symcgieuakksimmu(); Purchase::symcgieuakksimmu(); Component::symcgieuakksimmu(); } }
