<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681075957227             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Model; use Pmpr\Module\ComponentManager\Container; class Model extends Container { public function mameiwsayuyquoeq() { Report::symcgieuakksimmu(); Purchase::symcgieuakksimmu(); Component::symcgieuakksimmu(); } }
