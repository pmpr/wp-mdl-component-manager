<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b3f9cf876da             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Model; use Pmpr\Module\ComponentManager\Container; class Model extends Container { public function mameiwsayuyquoeq() { Report::symcgieuakksimmu(); Request::symcgieuakksimmu(); Purchase::symcgieuakksimmu(); Component::symcgieuakksimmu(); Campaign::symcgieuakksimmu(); Installation::symcgieuakksimmu(); } }
