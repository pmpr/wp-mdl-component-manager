<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5c95242e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Model; use Pmpr\Module\ComponentManager\Container; class Model extends Container { public function mameiwsayuyquoeq() { Report::symcgieuakksimmu(); Request::symcgieuakksimmu(); Purchase::symcgieuakksimmu(); Component::symcgieuakksimmu(); Campaign::symcgieuakksimmu(); Installation::symcgieuakksimmu(); } }
