<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b7bdc11a561             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Campaign extends Common { const ukmumwwqqeeyescc = "\x69\x6e\x73\164\141\154\x6c\141\164\x69\x6f\156\x5f\x69\x64"; public $timestamps = []; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->guiaswksukmgageq(__("\103\x61\x6d\160\141\x69\x67\156", PR__MDL__COMPONENT_MANAGER))->muuwuqssqkaieqge(__("\103\x61\155\x70\x61\x69\147\x6e\163", PR__MDL__COMPONENT_MANAGER))->yioesawwewqaigow(IconInterface::wsueeasywwmsikqe)->gemkqqguesukeocw()->wkesqcmiekqoykag()->aseucqksocwomwos()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::qescuiwgsyuikume)->gswweykyogmsyawy(__("\124\x69\164\x6c\145", PR__MDL__COMPONENT_MANAGER)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::ukmumwwqqeeyescc)->gswweykyogmsyawy(__("\x54\x69\x74\154\x65", PR__MDL__COMPONENT_MANAGER))->ckgquisaimmgwuyu(Installation::class)); parent::ewaqwooqoqmcoomi(); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::qescuiwgsyuikume)); parent::aoqwywcqmoqaukkq(); } }
