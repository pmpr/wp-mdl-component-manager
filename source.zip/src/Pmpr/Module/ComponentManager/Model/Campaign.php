<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b939727b32d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Campaign extends Common { const ukmumwwqqeeyescc = "\x69\x6e\163\x74\141\x6c\x6c\141\x74\151\157\156\x5f\x69\x64"; public $timestamps = []; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->guiaswksukmgageq(__("\x43\141\x6d\x70\x61\151\147\x6e", PR__MDL__COMPONENT_MANAGER))->muuwuqssqkaieqge(__("\x43\x61\155\x70\141\151\147\156\163", PR__MDL__COMPONENT_MANAGER))->yioesawwewqaigow(IconInterface::wsueeasywwmsikqe)->gemkqqguesukeocw()->wkesqcmiekqoykag()->aseucqksocwomwos()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::qescuiwgsyuikume)->gswweykyogmsyawy(__("\x54\x69\164\154\145", PR__MDL__COMPONENT_MANAGER)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::ukmumwwqqeeyescc)->gswweykyogmsyawy(__("\x54\151\x74\x6c\145", PR__MDL__COMPONENT_MANAGER))->ckgquisaimmgwuyu(Installation::class)); parent::ewaqwooqoqmcoomi(); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::qescuiwgsyuikume)); parent::aoqwywcqmoqaukkq(); } }
