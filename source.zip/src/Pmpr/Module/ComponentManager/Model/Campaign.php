<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5c95242e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Campaign extends Common { const ukmumwwqqeeyescc = "\151\156\163\x74\x61\154\154\141\x74\x69\x6f\x6e\x5f\x69\x64"; public $timestamps = []; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->guiaswksukmgageq(__("\103\x61\155\160\141\x69\147\x6e", PR__MDL__COMPONENT_MANAGER))->muuwuqssqkaieqge(__("\103\141\x6d\160\141\151\147\156\x73", PR__MDL__COMPONENT_MANAGER))->yioesawwewqaigow(IconInterface::wsueeasywwmsikqe)->gemkqqguesukeocw()->wkesqcmiekqoykag()->aseucqksocwomwos()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::qescuiwgsyuikume)->gswweykyogmsyawy(__("\124\151\x74\154\145", PR__MDL__COMPONENT_MANAGER)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::ukmumwwqqeeyescc)->gswweykyogmsyawy(__("\124\151\x74\154\145", PR__MDL__COMPONENT_MANAGER))->ckgquisaimmgwuyu(Installation::class)); parent::ewaqwooqoqmcoomi(); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::qescuiwgsyuikume)); parent::aoqwywcqmoqaukkq(); } }
