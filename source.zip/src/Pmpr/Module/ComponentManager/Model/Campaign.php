<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d7322bfbb4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Campaign extends Common { const ukmumwwqqeeyescc = "\151\x6e\163\164\x61\x6c\154\141\164\151\157\x6e\x5f\151\x64"; public $timestamps = []; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->guiaswksukmgageq(__("\x43\141\x6d\160\141\151\x67\x6e", PR__MDL__COMPONENT_MANAGER))->muuwuqssqkaieqge(__("\x43\141\x6d\x70\x61\151\x67\156\163", PR__MDL__COMPONENT_MANAGER))->yioesawwewqaigow(IconInterface::wsueeasywwmsikqe)->gemkqqguesukeocw()->wkesqcmiekqoykag()->aseucqksocwomwos()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::qescuiwgsyuikume)->gswweykyogmsyawy(__("\x54\x69\x74\154\x65", PR__MDL__COMPONENT_MANAGER)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::ukmumwwqqeeyescc)->gswweykyogmsyawy(__("\124\151\x74\154\145", PR__MDL__COMPONENT_MANAGER))->ckgquisaimmgwuyu(Installation::class)); parent::ewaqwooqoqmcoomi(); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::qescuiwgsyuikume)); parent::aoqwywcqmoqaukkq(); } }
