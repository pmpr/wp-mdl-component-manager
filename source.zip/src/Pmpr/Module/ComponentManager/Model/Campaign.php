<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4018f4d232             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Campaign extends Common { const ukmumwwqqeeyescc = "\x69\x6e\163\164\x61\154\x6c\x61\x74\151\157\x6e\x5f\x69\x64"; public $timestamps = []; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->guiaswksukmgageq(__("\103\x61\x6d\160\x61\x69\147\156", PR__MDL__COMPONENT_MANAGER))->muuwuqssqkaieqge(__("\x43\x61\x6d\160\x61\x69\x67\156\x73", PR__MDL__COMPONENT_MANAGER))->yioesawwewqaigow(IconInterface::wsueeasywwmsikqe)->gemkqqguesukeocw()->wkesqcmiekqoykag()->aseucqksocwomwos()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(self::qescuiwgsyuikume)->gswweykyogmsyawy(__("\x54\x69\164\x6c\x65", PR__MDL__COMPONENT_MANAGER)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::ukmumwwqqeeyescc)->gswweykyogmsyawy(__("\x54\151\164\x6c\x65", PR__MDL__COMPONENT_MANAGER))->ckgquisaimmgwuyu(Installation::class)); parent::ewaqwooqoqmcoomi(); } public function aoqwywcqmoqaukkq() { $this->mkksewyosgeumwsa($this->ymuegqgyuagyucws(self::qescuiwgsyuikume)); parent::aoqwywcqmoqaukkq(); } }
