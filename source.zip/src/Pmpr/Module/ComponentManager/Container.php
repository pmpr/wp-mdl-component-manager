<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66aeb5c95242e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const ieicsweaowmycywa = "\143\x6f\155\x70\x6f\x6e\145\x6e\x74\x5f\155\141\156\x61\x67\145\x72\x5f"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
