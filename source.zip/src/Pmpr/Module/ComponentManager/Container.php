<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e4c033d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const ieicsweaowmycywa = "\x63\x6f\x6d\x70\157\x6e\x65\x6e\164\137\x6d\x61\x6e\x61\x67\145\162\x5f"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
