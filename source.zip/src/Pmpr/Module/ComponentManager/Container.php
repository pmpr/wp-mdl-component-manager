<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd8a5b9d3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const ieicsweaowmycywa = "\143\x6f\x6d\160\x6f\156\145\x6e\x74\x5f\x6d\x61\x6e\141\x67\x65\162\137"; }
