<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b7bdc11a561             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const ieicsweaowmycywa = "\x63\x6f\x6d\x70\157\x6e\145\x6e\164\x5f\x6d\x61\x6e\x61\147\145\x72\x5f"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
