<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b939727b32d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { const ieicsweaowmycywa = "\x63\x6f\x6d\x70\157\156\145\156\x74\137\x6d\141\156\x61\147\145\x72\137"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
