<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6184c6e3eb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\PushUpdate; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const oyouaagycauaqgkc = "\143\x6f\x6d\160\x6f\156\145\x6e\164\x5f\x6d\141\x6e\x61\x67\x65\162\137\152\x6f\x62\x5f\160\x75\163\150\137\x75\160\x64\x61\164\145"; public function eamuuiioigiouimg($wksoawcgagcgoask, $wqogggcaamgeiwew) : int { $ksaameoqigiaoigg = 0; if ($this->yyuksmqogammigqm($wksoawcgagcgoask)) { goto mogkoocsoeuyoqqa; } $this->ksicwcssyugsigka(time(), self::oyouaagycauaqgkc, [self::ocwsuwyiiasigqaa => $wksoawcgagcgoask, self::oyaoekcogwkcekcc => $wqogggcaamgeiwew]); mogkoocsoeuyoqqa: return $ksaameoqigiaoigg; } public function yyuksmqogammigqm($wksoawcgagcgoask) : bool { return $this->exists([self::cmooywkooekaakwk => self::oyouaagycauaqgkc, self::okeuagwgwkmiokac => [self::ocwsuwyiiasigqaa => $wksoawcgagcgoask]]); } }
