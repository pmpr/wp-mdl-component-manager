<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d563249fee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\PushUpdate; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const oyouaagycauaqgkc = "\x63\x6f\155\x70\x6f\x6e\145\156\164\137\155\141\156\141\x67\x65\162\137\152\157\142\x5f\x70\x75\x73\150\x5f\x75\160\x64\141\164\x65"; public function eamuuiioigiouimg($wksoawcgagcgoask, $wqogggcaamgeiwew) : int { $ksaameoqigiaoigg = 0; if ($this->yyuksmqogammigqm($wksoawcgagcgoask)) { goto cuykwgmswkskqkyi; } $this->ksicwcssyugsigka(time(), self::oyouaagycauaqgkc, [self::ocwsuwyiiasigqaa => $wksoawcgagcgoask, self::oyaoekcogwkcekcc => $wqogggcaamgeiwew]); cuykwgmswkskqkyi: return $ksaameoqigiaoigg; } public function yyuksmqogammigqm($wksoawcgagcgoask) : bool { return $this->exists([self::cmooywkooekaakwk => self::oyouaagycauaqgkc, self::okeuagwgwkmiokac => [self::ocwsuwyiiasigqaa => $wksoawcgagcgoask]]); } }
