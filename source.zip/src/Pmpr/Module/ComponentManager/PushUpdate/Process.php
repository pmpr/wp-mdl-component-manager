<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6681a8aa6ea3a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\PushUpdate; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const oyouaagycauaqgkc = "\x63\157\x6d\x70\x6f\156\145\156\164\137\155\x61\x6e\x61\147\145\x72\x5f\152\x6f\142\137\x70\165\163\150\137\165\160\144\141\164\145"; public function eamuuiioigiouimg($wksoawcgagcgoask, $wqogggcaamgeiwew) : int { $ksaameoqigiaoigg = 0; if ($this->yyuksmqogammigqm($wksoawcgagcgoask)) { goto ocywegekakimmwcq; } $this->ksicwcssyugsigka(time(), self::oyouaagycauaqgkc, [self::ocwsuwyiiasigqaa => $wksoawcgagcgoask, self::oyaoekcogwkcekcc => $wqogggcaamgeiwew]); ocywegekakimmwcq: return $ksaameoqigiaoigg; } public function yyuksmqogammigqm($wksoawcgagcgoask) : bool { return $this->exists([self::cmooywkooekaakwk => self::oyouaagycauaqgkc, self::okeuagwgwkmiokac => [self::ocwsuwyiiasigqaa => $wksoawcgagcgoask]]); } }
