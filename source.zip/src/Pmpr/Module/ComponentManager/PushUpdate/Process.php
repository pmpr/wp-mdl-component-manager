<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400c19633a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\PushUpdate; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const oyouaagycauaqgkc = "\143\157\x6d\x70\x6f\156\x65\156\164\137\155\x61\x6e\141\147\145\162\137\x6a\157\142\137\x70\x75\163\x68\x5f\x75\x70\144\141\x74\x65"; public function eamuuiioigiouimg($wksoawcgagcgoask, $wqogggcaamgeiwew) : int { $ksaameoqigiaoigg = 0; if ($this->yyuksmqogammigqm($wksoawcgagcgoask)) { goto ocywegekakimmwcq; } $this->ksicwcssyugsigka(time(), self::oyouaagycauaqgkc, [self::ocwsuwyiiasigqaa => $wksoawcgagcgoask, self::oyaoekcogwkcekcc => $wqogggcaamgeiwew]); ocywegekakimmwcq: return $ksaameoqigiaoigg; } public function yyuksmqogammigqm($wksoawcgagcgoask) : bool { return $this->exists([self::cmooywkooekaakwk => self::oyouaagycauaqgkc, self::okeuagwgwkmiokac => [self::ocwsuwyiiasigqaa => $wksoawcgagcgoask]]); } }
