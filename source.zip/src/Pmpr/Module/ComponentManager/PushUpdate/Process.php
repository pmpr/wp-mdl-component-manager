<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4432a54e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\PushUpdate; use Pmpr\Common\Foundation\Process\Queue; class Process extends Queue { const oyouaagycauaqgkc = "\143\x6f\155\x70\157\156\145\x6e\164\x5f\x6d\141\156\x61\x67\145\162\x5f\x6a\x6f\142\x5f\160\165\163\150\137\x75\160\x64\141\164\x65"; public function eamuuiioigiouimg($wksoawcgagcgoask, $wqogggcaamgeiwew) : int { $ksaameoqigiaoigg = 0; if ($this->yyuksmqogammigqm($wksoawcgagcgoask)) { goto ciucewqgyoiouesq; } $this->ksicwcssyugsigka(time(), self::oyouaagycauaqgkc, [self::ocwsuwyiiasigqaa => $wksoawcgagcgoask, self::oyaoekcogwkcekcc => $wqogggcaamgeiwew]); ciucewqgyoiouesq: return $ksaameoqigiaoigg; } public function yyuksmqogammigqm($wksoawcgagcgoask) : bool { return $this->exists([self::cmooywkooekaakwk => self::oyouaagycauaqgkc, self::okeuagwgwkmiokac => [self::ocwsuwyiiasigqaa => $wksoawcgagcgoask]]); } }
