<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66a2f4432a54e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Packagist; use Pmpr\Common\Foundation\Process\Queue; use Pmpr\Module\ComponentManager\Setting; class Process extends Queue { const yumykisagyamsiig = "\x6a\x6f\142\137\x63\x68\x65\x63\153\137\x70\x61\x63\153\141\x67\151\x73\x74\x5f\x75\160\144\x61\164\145"; public function ykoymiawuuaccgqu() { $this->cancel(self::yumykisagyamsiig); } public function eacygoqqguiqosiq() : int { $ykquycoiqesuckco = Setting::symcgieuakksimmu(); $yiuogaeewyockeak = $ykquycoiqesuckco->giiuwsmyumqwwiyq(Setting::qkcusmuuciksieoy, "\61\67\x3a\64\63\x3a\64\60"); $yiuogaeewyockeak = strtotime(date("\131\55\155\x2d\x64") . "\40{$yiuogaeewyockeak}"); $cukawkgykqoskaca = $ykquycoiqesuckco->giiuwsmyumqwwiyq(Setting::gomeigayyekgimuo); if (!(!$cukawkgykqoskaca || !array_key_exists($cukawkgykqoskaca, $this->uwkmaywceaaaigwo()->cuwcwgaeiugaccei()->mggeycowqkwsieew()))) { goto asmecuqiyyswueqe; } $cukawkgykqoskaca = self::wmasmcgmyeoaisoa; asmecuqiyyswueqe: return $this->ooosmymooksgmyos($yiuogaeewyockeak, $cukawkgykqoskaca, self::yumykisagyamsiig); } }
