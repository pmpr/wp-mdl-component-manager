<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707f66215d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Packagist; use Pmpr\Common\Foundation\Process\Queue; use Pmpr\Module\ComponentManager\Setting; class Process extends Queue { const yumykisagyamsiig = "\x6a\x6f\x62\x5f\x63\x68\145\143\153\137\160\141\x63\153\141\x67\151\x73\x74\x5f\165\x70\144\141\164\x65"; public function ykoymiawuuaccgqu() { $this->cancel(self::yumykisagyamsiig); } public function eacygoqqguiqosiq() : int { $ykquycoiqesuckco = Setting::symcgieuakksimmu(); $yiuogaeewyockeak = $ykquycoiqesuckco->giiuwsmyumqwwiyq(Setting::qkcusmuuciksieoy, "\61\67\72\64\x33\x3a\64\60"); $yiuogaeewyockeak = strtotime(date("\131\x2d\x6d\55\x64") . "\40{$yiuogaeewyockeak}"); $cukawkgykqoskaca = $ykquycoiqesuckco->giiuwsmyumqwwiyq(Setting::gomeigayyekgimuo); if (!(!$cukawkgykqoskaca || !array_key_exists($cukawkgykqoskaca, $this->uwkmaywceaaaigwo()->cuwcwgaeiugaccei()->mggeycowqkwsieew()))) { goto kecwuwwcwokuksyq; } $cukawkgykqoskaca = self::wmasmcgmyeoaisoa; kecwuwwcwokuksyq: return $this->ooosmymooksgmyos($yiuogaeewyockeak, $cukawkgykqoskaca, self::yumykisagyamsiig); } }
