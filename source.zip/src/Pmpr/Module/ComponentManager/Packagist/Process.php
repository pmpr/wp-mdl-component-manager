<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d7322bfbb4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Packagist; use Pmpr\Common\Foundation\Process\Queue; use Pmpr\Module\ComponentManager\Setting; class Process extends Queue { const yumykisagyamsiig = "\x6a\x6f\142\137\143\150\x65\x63\153\137\x70\141\143\x6b\x61\147\151\x73\x74\137\x75\x70\144\141\x74\x65"; public function ykoymiawuuaccgqu() { $this->cancel(self::yumykisagyamsiig); } public function eacygoqqguiqosiq() : int { $ykquycoiqesuckco = Setting::symcgieuakksimmu(); $yiuogaeewyockeak = $ykquycoiqesuckco->giiuwsmyumqwwiyq(Setting::qkcusmuuciksieoy, "\x31\67\72\x34\x33\x3a\64\x30"); $yiuogaeewyockeak = strtotime(date("\131\x2d\155\55\144") . "\40{$yiuogaeewyockeak}"); $cukawkgykqoskaca = $ykquycoiqesuckco->giiuwsmyumqwwiyq(Setting::gomeigayyekgimuo); if (!(!$cukawkgykqoskaca || !array_key_exists($cukawkgykqoskaca, $this->uwkmaywceaaaigwo()->cuwcwgaeiugaccei()->mggeycowqkwsieew()))) { goto eeyyskqsmquyquqw; } $cukawkgykqoskaca = self::wmasmcgmyeoaisoa; eeyyskqsmquyquqw: return $this->ooosmymooksgmyos($yiuogaeewyockeak, $cukawkgykqoskaca, self::yumykisagyamsiig); } }
