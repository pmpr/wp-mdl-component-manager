<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669c4445875de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Packagist; use Pmpr\Common\Foundation\Process\Queue; use Pmpr\Module\ComponentManager\Setting; class Process extends Queue { const yumykisagyamsiig = "\x6a\157\x62\x5f\143\x68\x65\143\153\137\x70\141\143\153\x61\147\151\x73\x74\137\165\160\x64\x61\164\x65"; public function ykoymiawuuaccgqu() { $this->cancel(self::yumykisagyamsiig); } public function eacygoqqguiqosiq() : int { $ykquycoiqesuckco = Setting::symcgieuakksimmu(); $yiuogaeewyockeak = $ykquycoiqesuckco->giiuwsmyumqwwiyq(Setting::qkcusmuuciksieoy, "\x31\67\x3a\64\x33\72\64\60"); $yiuogaeewyockeak = strtotime(date("\131\55\155\55\144") . "\40{$yiuogaeewyockeak}"); $cukawkgykqoskaca = $ykquycoiqesuckco->giiuwsmyumqwwiyq(Setting::gomeigayyekgimuo); if (!(!$cukawkgykqoskaca || !array_key_exists($cukawkgykqoskaca, $this->uwkmaywceaaaigwo()->cuwcwgaeiugaccei()->mggeycowqkwsieew()))) { goto eeyyskqsmquyquqw; } $cukawkgykqoskaca = self::wmasmcgmyeoaisoa; eeyyskqsmquyquqw: return $this->ooosmymooksgmyos($yiuogaeewyockeak, $cukawkgykqoskaca, self::yumykisagyamsiig); } }
