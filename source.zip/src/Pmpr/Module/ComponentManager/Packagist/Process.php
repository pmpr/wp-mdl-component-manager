<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669ada7994f22             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Packagist; use Pmpr\Common\Foundation\Process\Queue; use Pmpr\Module\ComponentManager\Setting; class Process extends Queue { const yumykisagyamsiig = "\152\157\x62\137\143\x68\x65\x63\x6b\137\x70\x61\143\x6b\x61\147\x69\163\x74\137\165\x70\x64\x61\164\x65"; public function ykoymiawuuaccgqu() { $this->cancel(self::yumykisagyamsiig); } public function eacygoqqguiqosiq() : int { $ykquycoiqesuckco = Setting::symcgieuakksimmu(); $yiuogaeewyockeak = $ykquycoiqesuckco->giiuwsmyumqwwiyq(Setting::qkcusmuuciksieoy, "\61\67\x3a\x34\63\72\x34\x30"); $yiuogaeewyockeak = strtotime(date("\x59\55\x6d\x2d\x64") . "\40{$yiuogaeewyockeak}"); $cukawkgykqoskaca = $ykquycoiqesuckco->giiuwsmyumqwwiyq(Setting::gomeigayyekgimuo); if (!(!$cukawkgykqoskaca || !array_key_exists($cukawkgykqoskaca, $this->uwkmaywceaaaigwo()->cuwcwgaeiugaccei()->mggeycowqkwsieew()))) { goto cscusseysqygsoiy; } $cukawkgykqoskaca = self::wmasmcgmyeoaisoa; cscusseysqygsoiy: return $this->ooosmymooksgmyos($yiuogaeewyockeak, $cukawkgykqoskaca, self::yumykisagyamsiig); } }
