<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b4018f4d232             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Frontend; class Frontend extends Common { public function mameiwsayuyquoeq() { } }
