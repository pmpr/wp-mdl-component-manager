<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66b6184c6e3eb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Frontend; class Frontend extends Common { public function mameiwsayuyquoeq() { } }
