<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669f570b9bb41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Frontend; use Pmpr\Common\Foundation\Frontend\MultistepAware; abstract class Common extends MultistepAware { }
