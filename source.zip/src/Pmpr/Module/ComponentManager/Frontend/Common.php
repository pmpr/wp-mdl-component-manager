<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             669d7322bfbb4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ComponentManager\Frontend; use Pmpr\Common\Foundation\Frontend\MultistepAware; abstract class Common extends MultistepAware { }
